<?php
declare(strict_types=1);

namespace Lcobucci\JWT;

use RuntimeException;

abstract class Exception extends RuntimeException
{
}
